# Pelmeni Clicker — test plan for server economy

**Status:** plan only. No SQL or game code has been run against Supabase. Run this only against a disposable local PostgreSQL database or an isolated Supabase test project with synthetic profiles.

## 1. Before database tests

1. Confirm the real `public.player_state` column types, unique key on `telegram_id`, RLS, grants, and role used by `ctx.supabaseAdmin`.
2. Confirm that the `public` schema is exposed to PostgREST RPC and that `service_role` is the actual trusted RPC role. Confirm `anon` and `authenticated` role behavior.
3. Apply the migration only to a throwaway database initialized with the confirmed minimum schema and a synthetic player. Do not copy production player rows into a shared test environment.
4. Insert a control row for that synthetic player with `server_mode = true` and `state_schema_version = 6` as test setup only. The prepared migration intentionally does not activate real profiles.
5. Compare SQL results with `game-rules.js` for cooking duration, upgrade costs, reward range, score thresholds, and task/level rewards.
6. Confirm that `player_state` still has the checked `telegram_id`, `game_state`, and `updated_at` columns and that the `BEFORE INSERT OR UPDATE` guard can read `player_economy_control` under the actual RPC role. With `row_security = off`, non-bypass roles must fail closed if RLS would hide the control row.
7. Enumerate every role with effective `INSERT` or `UPDATE` access to `player_state`, including inherited table grants and role memberships. Check which roles can assume `service_role`. Confirm whether `authenticator` is the actual private PostgREST gateway; the migration exempts only that gateway identity. The preflight must stop if any other non-superuser role can assume `service_role`; resolve that membership before continuing.

## 2. Idempotency and concurrency

| Scenario | Action | Expected result |
|---|---|---|
| Same request repeated | Call one operation twice with the same player, `requestId`, action, and parameters | One state mutation; second call returns the saved operation result and current canonical state/revision. |
| Conflicting request ID | Reuse a prior `requestId` with a different action or parameters | `idempotency_conflict`; no new mutation and no replacement of the original receipt. |
| Parallel exact retry | Send the same request concurrently | One applied result; the other sees the receipt after the profile-row lock; one increment/reward total. |
| Parallel distinct collection requests | Two request IDs collect the same ready `batchId` | At most one collection and one reward; the second sees the batch absent/already handled and changes no economic field. |
| Parallel purchases at boundary balance | Two different purchase requests whose combined prices exceed balance | Serialized decisions; balance never becomes negative and no partial purchase occurs. |
| Retry after UTC midnight | Repeat an already recorded request after the UTC day changes | Return the stored outcome and current canonical state/revision; do not apply it again. |
| Stale daily state | Send a new command after midnight before `economy_load_visit` has rolled the profile forward | Return `daily_state_stale` without mutation, revision increment, or request receipt; after `load_visit`, a new attempt may proceed against today's tasks. |
| Repeated equip no-op | Request equip/remove when the decoration already has that state, using a new request ID | Record the request outcome for idempotency, but leave `game_state`, `revision`, and `player_state.updated_at` unchanged. Exact retry returns that recorded outcome. |
| Collect either pot while the other is active | Create two distinct active batches, collect one ready batch, then inspect `activeBatches`, `startedAt`, `endsAt`, and `batchDurationMs` | The collected batch is removed. The single-batch compatibility fields match the remaining primary batch (pot 1 first, otherwise pot 2). The other batch retains its original id, pot, start/end time, and duration and remains collectible. Repeat with the other pot as the collected batch. |
| Collect the final active batch | Collect the only ready batch | `activeBatches` is empty and `startedAt`, `endsAt`, and `batchDurationMs` are JSON null; no stale timer remains in the compatibility fields. |

Also inspect `player_economy_requests`: one `(telegram_id, request_id)` row per accepted request key, stable action/parameters/outcome, and no Telegram `initData` stored there.

## 3. Game rules and rejected operations

- Start a batch with no upgrades and verify 10,000 ms; with stove levels 1 and 10 verify 9,500 ms and 5,000 ms. `blue-tile` and `wooden-spoon` each subtract 3,000 ms before the 4,000 ms floor; with both equipped, final duration is 4,000 ms, not 3,000 ms.
- Reject pot 2 without equipped `second-pot`, a duplicate occupied slot, invalid pot values, unknown upgrade/decoration/task IDs, and invalid equip values.
- For each known upgrade, test level values `-1`, `11`, fractional JSON numbers, strings, malformed types, and a non-object `upgradeLevels` field. They must be rejected as `invalid_upgrade_level` before a price is calculated or state/revision changes. Test omitted level as level 0 and level 10 as maxed.
- For every operation and `economy_load_visit`, test a missing `schemaVersion`, string/fractional version, unknown version, and a mismatch between `game_state.schemaVersion` and `player_economy_control.state_schema_version`. Expect `unsupported_game_state_schema`, no state or timestamp change, no revision change, and no idempotency row. The supported test fixture must explicitly set both versions to 6.
- Check first-level upgrade costs are 67 / 100 / 133 (stove / larger pot / recipe), then compare later levels with `upgradeCost` for all levels 0–9. Ensure maximum level 10 is rejected.
- For rewards, verify server roll is within 10–15 and compare exact result for all recipe and pot levels and legacy bonuses against `batchDumplingReward`. Verify `second-pot` itself never multiplies the reward.
- Reject an early collection, insufficient-balance purchase, collection of a missing batch, incomplete task, already claimed daily task, already claimed level, and level below its score threshold. Rejections must not alter balance, score, lifetime earnings, batches, purchases, task claims, or revision.
- Verify daily task values: cook 10, collect 5, collect-at-least-30 10, upgrade 15, both pots 5; level reward is `10 + max(0, level - 2) * 5`. A level claim increases balance and score but not `lifetimeDumplings`.
- Verify equipped decorations affect duration/reward exactly as the current code does and removing `second-pot` leaves an already running second-slot batch collectible.
- For malformed stored state, test each economic command and `economy_load_visit` with invalid types and invalid values in `activeBatches`, `dailyTasks`, `upgradeLevels`, `upgrades`, `equipped`, `levelClaims`, `taskPotsUsed`, `potCollections`, and numeric balance/progress fields. Include object/string/null instead of required arrays or objects; non-object daily-task entries; fractional, negative, string, and out-of-range levels/progress; duplicate batch IDs or pots; a batch with missing/invalid id, pot, or timestamps; and nonnumeric counters. Expect `invalid_game_state_shape` before any state, timestamp, revision, or request-receipt mutation. Verify the original JSON is unchanged; no automatic repair or normalization is allowed. Also inject a database exception during a valid operation and confirm full transactional rollback as in section 4.

## 4. Atomic rollback on internal failure

In the disposable database only, add a temporary `BEFORE UPDATE` trigger on `player_economy_control` that raises for the synthetic profile. Each operation updates `player_state` first and `player_economy_control` second, so this injects the failure after the state write has executed. Call a purchase, collection, task claim, and `load/visit` separately. For command operations, assert that all of the following roll back together; for `load/visit`, check the state and revision (that RPC has no request receipt):

- `player_state.game_state` and `updated_at`;
- `player_economy_control.revision`;
- for commands, the idempotency request row.

Remove the temporary failure trigger and retry the command with the same request ID. It should then apply once. For `load/visit`, retry and verify the visit reward/date marker is applied once. A business rejection should be recorded as an idempotent rejected outcome; a database exception should roll the whole SQL call back and should not reserve the command request ID.

## 5. `load/visit`, daily rollover, and versioned response

- New synthetic profile in server mode with normalized first-visit fields (no `joinedAt`, batches, balance, owned decoration, or positive known upgrade level): call `economy_load_visit`. Expect `first-visit`, `firstLoginNoReward = true`, today's UTC `loginRewardDate`, claimed login task, no +5 balance/score/lifetime award, canonical `state`, `revision`, `protocolVersion: 1`, and `gameStateSchemaVersion: 6`.
- Repeat `economy_load_visit` on that profile on the same UTC day. Expect no second award and no second revision increment once the response state is already current.
- For a returning profile with yesterday's `dailyDate` and `loginRewardDate`, set nonzero daily task progress and a previous UTC streak date. Visit once: daily fields reset, login gives exactly +5 to `balance`, `score`, and `lifetimeDumplings`, login task is claimed, and streak fields advance according to `advanceStreak`.
- Regression case: set `loginRewardDate` to today's UTC date while `dailyDate` and `taskDay` are yesterday, and include nonzero yesterday task progress. Call `economy_load_visit`: daily task progress/claims and daily counters reset for the new day, `loginRewardDate` remains today's date, the login task is marked complete, and balance/score/`lifetimeDumplings` do not receive another +5. Repeat the call and verify no additional state or revision change.
- Repeat the returning visit on the same UTC day: no second +5; check both `loginRewardDate` and the three balances/counters.
- Run two concurrent visits for the same returning profile in separate database sessions. Both may return the canonical state, but the reward is applied once, with a single state/revision change.
- Test a stored future `dailyDate`: it must not roll backward or grant a login reward, matching the current client clock-skew guard.
- Verify the response contains `protocolVersion` separately from the game's `schemaVersion` (currently 6); it must not label protocol version as `schemaVersion`. A state missing `schemaVersion` must be handled deliberately, not silently called version 6 unless it has been validated/upgraded.
- A missing `player_state` row or missing/disabled control row must fail closed and must not create a profile or import browser/localStorage data.
- Block `load_visit` on the profile lock across UTC midnight. It must use the UTC date after both locks, reset `dailyDate`, `taskDay`, daily task progress/claims and related daily counters once, award returning-player +5 at most once, and increment revision once. A concurrent second visit must observe the new state and add neither a duplicate reward nor revision.
- Test a profile whose `dailyDate` is today but `taskDay` is stale; `load_visit` must restore consistency before later commands are accepted.
- Start a command before midnight but let it obtain the profile lock after midnight. A new command with stale `dailyDate` or `taskDay` must return `daily_state_stale` without modifying yesterday's progress, revision, or request journal. Because this stale response is not journaled, call `load_visit` and retry with the same request ID and parameters.

### Legacy snapshot preflight (activation only; not performed by these RPCs)

`economy_load_visit` must not import, normalize, or rewrite a legacy snapshot to decide whether to give a first-visit reward. Before enabling a profile, activation tooling must lock its existing `player_state` row and run a read-only compatibility comparison against the exact current `normalizeState()` semantics. It must record the proposed result and differences for review; do not activate automatically when a difference is ambiguous. Preserve unknown fields and all confirmed purchases/progress. The migration currently contains no activation function or importer.

Use independent synthetic copies of these legacy snapshots and compare the dry-run result with `normalizeState()`:

| Legacy fields in stored snapshot | Expected preflight result |
|---|---|
| `upgradeLevels['second-pot'] > 0`, with no `upgrades` entry | Detect that normalization creates ownership of `second-pot`; classify as an existing player, not a first visit. Do not lose the purchase. |
| `pointsRetired !== true` and positive legacy `points` (or fallback `score`) | Detect the normalization's balance/score conversion; classify as an existing player. Preview the conversion once; do not let `load_visit` apply it. |
| `taskClaimedOn` and `loginRewardDate` are today, and `taskBalanceRewardVersion !== 1` | Detect the legacy +5 balance conversion and resulting version marker. After approved one-time activation, the conversion must not be repeated; keep `loginRewardDate` current in this fixture so a distinct login reward does not confuse the assertion. |

For each fixture, assert activation is refused until the preview is explicitly approved, the transformed snapshot is committed once while mode is disabled, and a second activation/import attempt cannot replay the conversion. Test an ambiguous legacy snapshot and verify it is routed to manual review without changing `game_state`, balance, purchases, timers, or claims.

## 6. Atomic legacy-save guard and authorization

- As `anon` and `authenticated`, direct `EXECUTE` on every public economy RPC must fail. Direct reads/writes to the new metadata and request tables must also fail.
- As the trusted server role, RPC execution succeeds only for a profile whose control row explicitly has `server_mode = true`.
- A profile without a control row, with `server_mode = false`, or without a matching `player_state` row returns a fail-closed response and is not created or modified.
- Before enabling any real profile, test that the Edge Function passes only the Telegram ID extracted from verified `initData`, never an ID copied from the request body.
- Reproduce the current Edge `save` write exactly as `INSERT ... ON CONFLICT (telegram_id) DO UPDATE SET game_state = ..., updated_at = ...` using the trusted test role and without the transaction-local economy marker. On an inactive profile it should retain current behavior; on an enabled profile it must fail in the trigger and leave `game_state`, `updated_at`, and `revision` unchanged.
- Run two sessions concurrently: one executes a server economy RPC while the other sends the old full-state upsert for that same enabled profile. In either lock order the old write must not commit after server mode is enabled; the state must be either the serialized server result or unchanged, never the stale client snapshot. Verify the service role and trigger use the same `player_state`-then-control lock order and watch for deadlocks.
- Exercise the future mode-switch transaction with a concurrent old upsert. In one transaction: (1) lock the existing `player_state` row `FOR UPDATE`; (2) inspect and preview the stored snapshot without trusting localStorage; (3) only after that lock, insert or lock the player's control row; (4) if approved normalization is necessary, preserve the source snapshot and apply the reviewed result while `server_mode` is still false; (5) set `state_schema_version = 6`, initialize the chosen revision, and set `server_mode = true` as the final data-changing step; (6) commit. If the old write wins first, activation must read its committed snapshot. If activation wins first, the upsert must wait and then be rejected by the trigger. Roll back all activation writes on any error. No real profiles are included in this test setup.
- Run the mode-switch race in both lock orders and assert there is no deadlock, no stale snapshot after activation, and no partially enabled control row. Preserve active batches unless a separately approved, evidence-based reconciliation is required; an ambiguous or untrusted timer goes to manual review and is never silently deleted, reset, or collected.
- Confirm server RPC writes succeed because they set `pelmeni.server_economy_write` transaction-locally after locks; confirm the marker is absent in a later transaction and cannot leak through connection pooling.
- Test `INSERT`/upsert for an enabled ID, ordinary updates, and attempts to change `telegram_id`. Test trigger behavior under every role that has write access to `player_state`.
- For every existing role found in the preflight inventory with direct or inherited write access to `player_state`, attempt an enabled-profile write with no marker and then with `SET LOCAL pelmeni.server_economy_write = 'allowed'`. A role other than `service_role` must be rejected in both cases; the marker is not authority by itself. Verify inherited table privileges do not bypass the trigger.
- Inspect direct and transitive role membership that could permit `SET ROLE service_role`. Confirm the actual private PostgREST gateway identity and verify it is not an application credential. Any other non-superuser membership is a migration preflight failure. In the disposable database, prove that no application/writer role can assume `service_role`; if any can, stop and remove/review that membership before proceeding. Retest the upsert after membership changes.
- As `service_role`, verify the marker is effective only within the RPC transaction and the RPC still writes correctly. The Edge Function's ordinary PostgREST upsert must not be able to set a transaction-local custom GUC. Treat superuser/database-owner access as privileged administrative access outside this application guard's threat boundary.
- The trigger prevents the current full-state upsert from overwriting server-mode rows without changing Edge Function code. The Edge Function still needs a later change to route `load`/commands through RPC and translate the trigger rejection into a deliberate client response; it is not yet a complete client cutover.

## 7. What this migration does not yet test or provide

- No RPC here activates existing profiles or imports local saves.
- The Edge Function is not changed to call `economy_load_visit` or the economy commands. Do not deploy or expose this schema as a completed client cutover.
- No profile activation, legacy normalization/import, or active-timer reconciliation function is included. The activation sequence above is a required future procedure, not implemented SQL. Legacy `second-pot`, `points`, and `taskClaimedOn` must be reconciled before first-visit evaluation; `load/visit` does not repair them.
- `gameStateSchemaVersion` is read from `game_state.schemaVersion`; RPCs require it to equal the control row's `state_schema_version`, currently supported value 6. They reject absent, unknown, or mismatched versions and do not assign a version automatically.
- The Edge Function and `app.js` are unchanged. The current client still expects `{ game_state }`, sends whole-state `save`, and mutates optimistically. A full switch requires coordinated Edge Function routing to RPC, canonical response/revision handling in the client, and an explicit stale-client/version response. The trigger blocks old saves for enabled profiles but does not make the old UI protocol-compatible.
- The trigger protects against the current Edge `save` because that code does not set the transaction-local marker. Any other trusted service-role code could set that marker; keep the service key private and audit all server-side writers before enabling profiles.
- The migration was not syntax-checked by PostgreSQL in this environment: `psql`, PostgreSQL server tools, Docker, and Supabase CLI are unavailable. A disposable database syntax/application test is a gate before any Supabase migration.
